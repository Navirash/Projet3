<template>
  <div>
    <div class="landing">
    <div class="home-wrap">
      <div class="home-inner"> 
        <img src="pink.jpg"> 
        </div>
    </div>
  </div>
  <div class="caption text-center">
    <h1> Frequently Asked Questions </h1>
    <h3> So, you want to know more about the website huh ? </h3>
  
  </div>
    <br>
   <h1 class="heading"> How this website works ?</h1>
   <div class="heading-underline"></div>
     <div id="accordion">
  <div class="card">
    <div class="card-header" id="headingOne">
      <h5 class="mb-0">
        <button class="btn btn-link" data-toggle="collapse" data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
          What is E-Chief ?
        </button>
      </h5>
    </div>

    <div id="collapseOne" class="collapse" aria-labelledby="headingOne" data-parent="#accordion">
      <div class="card-body">
        E-Chief is a site that lists thousands of recipes adapted to your needs: Indeed, the site generates a number of recipes according to the ingredients you keep in the refrigerator!
        But not only that! The site also provides recipes to suit your desires and your objectives:
        You want to eat Italian food? You want to go on a diet? You don't know which recipe to cook?
        Well it's perfect! This website is made for you!  
      </div>
    </div>
  </div>
  <div class="card">
    <div class="card-header" id="headingTwo">
      <h5 class="mb-0">
        <button class="btn btn-link collapsed" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
          How can I generate recipes ?
        </button>
      </h5>
    </div>
    <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordion">
      <div class="card-body">
        Nothing could be easier! Our website is designed to be as easy to use as possible! 
        Go to the search bar located in the home page. Enter the keywords that describe exactly 
        what you have (banana, apple...) or also what you want (French cuisine, weight gain for example) 
        and the site will take care of the rest by listing the recipes adapted to your needs! 
      </div>
    </div>
  </div>
  <div class="card">
    <div class="card-header" id="headingThree">
      <h5 class="mb-0">
        <button class="btn btn-link collapsed" data-toggle="collapse" data-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
          How can I be sure about the quality of the recipe?
        </button>
      </h5>
    </div>
    <div id="collapseThree" class="collapse" aria-labelledby="headingThree" data-parent="#accordion">
      <div class="card-body">
        Our top objective is that you are satisfied and fulfilled after using our services. 
        We have meticulously selected tasty and trustworthy recipes. 
        We want this website to be an essential tool that will assist you every day in your daily life.
      </div>
    </div>
  </div>
  <div class="card">
    <div class="card-header" id="headingOne">
      <h5 class="mb-0">
        <button class="btn btn-link" data-toggle="collapse" data-target="#collapseFour" aria-expanded="true" aria-controls="collapseFour">
          I would also like to submit recipes on this website! Will I be able to contribute some ?
        </button>
      </h5>
    </div>

    <div id="collapseFour" class="collapse" aria-labelledby="headingFour" data-parent="#accordion">
      <div class="card-body">
        This is an issue that the E-Chief team is currently working on at the site.  
        We promote creativity and sharing among users. It's just a question of time! 
      </div>
    </div>
  </div>
  <div class="card">
    <div class="card-header" id="headingOne">
      <h5 class="mb-0">
        <button class="btn btn-link" data-toggle="collapse" data-target="#collapseFive" aria-expanded="true" aria-controls="collapseFive">
          How to contact us? 
        </button>
      </h5>
    </div>

    <div id="collapseFive" class="collapse" aria-labelledby="headingFive" data-parent="#accordion">
      <div class="card-body">
        We are very attentive and consider the feedback you make on our site: If you have any questions please do not hesitate to contact us by message by going to the "about us" section. 
        We will try to answer them as soon as possible! We are available 7 days a week, 24 hours a day and 
        you can follow us on social networks, especially on our Instagram E-chief_official account where 
        we are very active!
      </div>
    </div>
  
  <footer>
        <div class="row justify-content-center">   
          <div class="col-md-5 text-center">
            <img src="echief.png">     <strong>E-CHIEF</strong>
            <p>Come and discover our famous recipes. At E-CHIEF we will be available 24/7 for all information. Please contact us by email or phone. We wish you a pleasant visit through our website. Thank you! </p>
            <strong> Contact information </strong>
            <p>+442041345678<br>e-chief@outlook.com</p>
            <a href="" target="_blank"><i class="fab fa-facebook-square"></i></a>
            <a href="" target="_blank"><i class="fab fa-twitter-square"></i></a>
            <a href="" target="_blank"><i class="fab fa-linkedin"></i></a>
          </div>
          <hr class="socket">
          Copyright © All rights reserved.
        </div>
      </footer>
  
  </div>
</template>

<script>
module.exports = {
  
  data () {
    return {
    }
  },
  async mounted () {
  },
  methods: {
  }
}
</script>

<style scoped>
.heading{
  font-size:1.9rem;
  font-weight:700;
  text-transform:uppercase;
  margin-bottom:1.9rem;
  text-align:center;
}
.heading-underline{
  width:3rem;
  height: .2rem;
  background-color:#FF69B4;
  margin:0 auto 2rem;
}

.home-inner img{
  height:600px;
  width:100%;
}

.caption{
  width:100%;
  max-width:100%;
  position:absolute;
  top:38%;
  z-index:1;
  color:white;
  text-transform:uppercase;
}

.caption h1{
  font-size:4.5rem;
  font-weight:700;
  letter-spacing:.3rem;
  text-shadow: .1rem .1rem .8rem black;
  padding-bottom: 1rem;
}
.caption h3{
  font-size: 1.5rem;
  text-shadow: .1rem .1rem .5rem black;
  padding-bottom:1.6rem;
}

button{
  color:#d8398b;
}

.btn-link{
  color:#e8167f;
}

.btn-link:hover{
  color:#9c0653;
}

footer{
  background-color:#F5D1CC;
  color:black;
  padding:2rem 0 2rem;
  margin-top:1rem;
}

footer img {
  height:4rem;
  margin:1.5rem 0;
}

footer a {
  color:#FF69B4;
}

footer svg.svg-inline--fa {
  font-size:2rem;
  margin:1.2rem .5rem 0 0;
}

footer svg.svg-inline--fa:hover {
  color:#FF1493;
}
hr.socket{
  width:100%;
  border-top:.2rem solid #FF1493;
  margin-top:3rem;
}
</style>
