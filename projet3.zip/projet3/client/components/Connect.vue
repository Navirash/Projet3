<template>
     <div>
    <div class="body"></div>
      <div class="inscription">
        <img src="echief.png">
      <h1> Connection</h1>
      <div class="form">
        <i class="fas fa-user"></i>
        <input type="text" v-model="email" placeholder="email" name="" value="">
      </div>
      <div class="form">
        <i class="fas fa-lock"></i>
        <input type="password" v-model="password" placeholder="password" name="" value="">
      </div>
          <br>
          <router-link  to='/register'><a> Not a member yet ? Register now ! </a></router-link>
          <br>
          <br>
        <input class="btn" type="button" value="Register now" v-on:click="connexion()">
    </div>
</div>
</template>

<script>
module.exports = {
    data(){
        return{
            email : "",
            password : "",
        }
    },
    methods : {
        connexion(email, mdp){
            this.$emit("connexion", email, mdp);
        }
    }
}
</script>

<style scoped>
.body{
  width:100%;
  height:100%;
  background-image: url('fond.jpg');
  background-size:cover;
  background-position:center;
  background-attachment:fixed;
  opacity:0.6;
}

.inscription{
  position:absolute;
  top:50%;
  left:50%;
  transform: translate(-50%,-50%);
  color:black;
  background-color:rgb(255,20,147, 0.09);
  padding:50px;
  border-radius:15px;
  height:60%
}

.inscription h1{
  float:left;
  font-size:40px;
  border-bottom: 6px solid #FF69B4;
  margin-bottom:50px;
  padding: 13px 0
}

.form {
  width:100%;
  overflow:hidden;
  font-size:20px;
  margin:8px 0;
  padding:8px 0;
  border-bottom: 1px solid #FF69B4;
}

.form i{
  width: 26px;
  float:left;
  text-align:center
}

.form input{
  border:none;
  outline:none;
  background-color:rgba(0,0,0,0);
  color:black;
  font-size:18px;
  width:80%;
  position:relative;
  left:10px;
}


.btn{
  width:100%;
  outline:none;
  background-color:rgba(0,0,0,0);
  border:2px solid #FF1493;
  color:black;
  padding:5px;
  font-size:18px;
  cursor:pointer;
  margin:12px 0;
}
img{
    width:100px;
    height:100px;
    display:block;
    margin-left:auto;
    margin-right:auto;
    position:absolute;
    top:-50px;
    left:37.6%;
}
</style>